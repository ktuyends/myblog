# currencyconvertervba
A currency converter in vba.

You can convert currencies and plot data for last 30 days. The file uses xe.com for conversion.
